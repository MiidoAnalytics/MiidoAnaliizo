

function showForm() {
	if (//(formContainer[currentForm].parent == 0) &&
			(formContainer[currentForm].cluster.style['display'] != 'none') &&
			(formContainer[currentForm].insider == 0) &&
			(formContainer[currentForm].id > 0)) {
		$( formContainer[currentForm].cluster ).hide();
		$( dNBButton ).hide();
		var direction;
		//console.log(formContainer[currentForm].cluster.style.visibility);
		if(ss == 1)
			direction = "rigth";
		else
			direction = "left"
	    dNBButton.style.display = "block";
		formContainer[currentForm].cluster.appendChild(dNBButton);
		targetContainer.appendChild(formContainer[currentForm].cluster);
		$( formContainer[currentForm].cluster ).show( "slide", { direction: direction}, "medium");
	} else {
		if(ss == 1)
			currentForm++;
		else
			currentForm--;
		if(currentForm < 0){
			ss = 1;
			currentForm++;
		}
		showForm();
	}
}

function changeForm(){
	if(validateRequired()){
		var direction;
		if(ss == 1)
			direction = "left";
		else
			direction = "rigth"
	    $( formContainer[currentForm].cluster ).hide( "slide", { direction: direction}, "medium");
	    $( dNBButton ).hide( "slide", { direction: direction }, "medium", ready);
	}
}

function ready(){
	targetContainer.removeChild(formContainer[currentForm].cluster);
	formContainer[currentForm].cluster.removeChild( dNBButton );
	$( formContainer[currentForm].cluster ).show( "slide" );
	//formContainer[currentForm].cluster
	if(ss == 1)
		currentForm++;
	else
		currentForm--;
	if(currentForm < 0){
		ss = 1;
		currentForm++;
	}
	showForm();
}