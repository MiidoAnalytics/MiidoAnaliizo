<?php
	require_once('lib/27052015/$_constants.php');
	/**
	* 
	*/
	class analiizoByMiido
	{
		var $p;
		var $d;
		var $v;
		var $m;
		var $o;

		function __construct() {}

		private function connect($db) {
			$conn = new mysqli(_HOST, _USER, _PASSWORD, $db);

			if ($conn->connect_errno) {
				die("something wrong! (X_x)");
			} else {
				return $conn;
			}
		}

		public function getCoreData(){
			
			$tmp = $this->_SELECT(
				_PEOPLE_T,
				((defined('_PEOPLE_C')) ? constant('_PEOPLE_C') : null),
				_PEOPLE_F,
				_PEOPLE_D );
			$this->p   = $this->_PARSE($tmp);
			
			$tmp = $this->_SELECT(
				_DISEASES_T,
				((defined('_DISEASES_C')) ? constant('_DISEASES_C') : null),
				_DISEASES_F,
				_DISEASES_D );
			$this->d   = $this->_PARSE($tmp);

			$tmp = $this->_SELECT(
				_CUMS_T,
				((defined('_CUMS_C')) ? constant('_CUMS_C') : null),
				_CUMS_F,
				_CUMS_D );
			$this->v   = $this->_PARSE($tmp);

			$tmp = $this->_SELECT(
				_CUPS_T,
				((defined('_CUPS_C')) ? constant('_CUPS_C') : null),
				_CUPS_F,
				_CUPS_D );
			$this->m   = $this->_PARSE($tmp);

			$tmp = $this->_SELECT(
				_CIUO_T,
				((defined('_CIUO_C')) ? constant('_CIUO_C') : null),
				_CIUO_F,
				_CIUO_D );
			$this->o   = $this->_PARSE($tmp);
		}

		private function _SELECT($target, $data, $response, $db){
			
			$data = ( ( isset( $data ) ) ? $data : '1' );
			$data = str_replace(_SP, ' AND ', $data);

			$query = "SELECT $response FROM $target WHERE $data;";

			$conn = $this->connect(constant('_DB'.$db));

			if ($tmp = $conn->query($query)){
				return $tmp;
			}
			return null;
		}

		private function _PARSE($data){
			if (null != $data) {
				$response = array();
				while ($row = $data->fetch_assoc()) {
					$response[] = $row;
				}
				$data->free();
				return $response;
			}
			$data->free();
			return null;
		}
	}
?>