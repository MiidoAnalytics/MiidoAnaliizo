var structure;
var fields_structure;
var options;
var forms;
var forms_order;
var handler_event;
var handlerFieldJoiner;
var fieldsJoiner;
var aditionalFieldsRules;
var documentInfo;

var ss;
var currentForm;
var targetContainer;

var dNBButton;
var nButton;
var bButton;

var formContainer   = new Array();
var objectContainer = new Array();

$(document).ready(function () {
    targetContainer = document.getElementById("masterDiv");
    ss = 1;
    currentForm = 0;
    init();
});


function init(){
    preloaded();
    setJSONStructure(strcuture_str);
    parseStructure();
    formsCreator();
    createObjects();
    createInterface(objectContainer, formContainer);
    prepareElements();
    createNextBackButton();
    addNBButtonHandler();
    showForm();
}

//for var url = "http://miidolinux.cloudapp.net:3000/key/Poll"; $.ajax({crossOrigin: true, type: "GET", url: url, success: function(data) {//console.log(data); alert(data); } }); var xmlhttp; xmlhttp = new XMLHttpRequest(); xmlhttp.onreadystatechange = function () {if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {alert(xmlhttp.responseText); alert("success"); } } xmlhttp.open("POST", url, true); xmlhttp.setRequestHeader('Content-Type', 'application/xml'); //xmlhttp.setRequestHeader("Content-Type", "application/json"); xmlhttp.setRequestHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept"); xmlhttp.setRequestHeader("Access-Control-Allow-Origin", "http://miidolinux.cloudapp.net"); xmlhttp.setRequestHeader('X-PINGOTHER', 'pingpong'); xmlhttp.setRequestHeader("Access-Control-Allow-Methods","POST, GET"); xmlhttp.setRequestHeader("Access-Control-Max-Age","1728000"); xmlhttp.send(); */

function preloaded(){
    var arr = "";
    for(var x in diseases){
      arr += ($.map(diseases[x], function(el) { return el; }));
    }
    diseases = arr;

    var arr = "";
    for(var x in people){
      arr += ($.map(people[x], function(el) { return el; }));
    }
    people = arr;

    var arr = "";
    for(var x in cums){
      arr += ($.map(cums[x], function(el) { return el; }));
    }
    cums = arr;

    var arr = "";
    for(var x in cups){
      arr += ($.map(cups[x], function(el) { return el; }));
    }
    cups = arr;

    var arr = "";
    for(var x in ciuo){
      arr += ($.map(ciuo[x], function(el) { return el; }));
    }
    ciuo = arr;
}