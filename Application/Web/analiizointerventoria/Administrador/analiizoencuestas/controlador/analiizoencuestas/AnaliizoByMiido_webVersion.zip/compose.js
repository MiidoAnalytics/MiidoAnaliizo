function formsCreator(){
    for (var i = 0; i < forms.length; i++) {
        formContainer[i] = new Array();
        formContainer[i].id = forms[i].Id;
        formContainer[i].parent = forms[i].Parent;
        formContainer[i].insider = forms[i].Inside;
        formContainer[i].cluster = document.createElement("FIELDSET");
        if (forms[i].Header != "") {
            var fs = document.createElement("LEGEND");
            fs.appendChild(document.createTextNode(forms[i].Header));
            formContainer[i].cluster.appendChild(fs);
        }
    };
}

function createObjects(){
	for(a = 0; a < fields_structure.length; a++){
		objectContainer[a] = new Array();
		objectContainer[a].id = fields_structure[a].Id;
		objectContainer[a].name = fields_structure[a].Name;
		objectContainer[a].label = document.createTextNode(fields_structure[a].Label);
        objectContainer[a].label.className = "demoHeaders";
		objectContainer[a].required = fields_structure[a].Required;
		objectContainer[a].form = fields_structure[a].Form;
		objectContainer[a].order = fields_structure[a].Order;
		objectContainer[a].handler = fields_structure[a].Handler;
		objectContainer[a].type = fields_structure[a].Type;
		objectContainer[a].dom = createField({
			objectType	: fields_structure[a].Type,
			hint 		: fields_structure[a].Hint,
            rules       : fields_structure[a].Rules,
            id          : fields_structure[a].Id,
			required 	: fields_structure[a].Required,
            autocomplete: fields_structure[a].AutoComplete
		});
	}
}

function createField(data){
	var dom;
	switch (data.objectType){
		case "tf":
			dom = document.createElement("INPUT");
            dom.type = setRules(data.rules);
            dom.setAttribute("placeholder", data.hint);
            dom.className = "ui-spinner ui-widget ui-widget-content ui-corner-all";
            break;
        case "dp":
        	dom = document.createElement("INPUT");
        	dom.type = "date";
            dom.className = "ui-datepicker-inline ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all";
            break;
        case "cb":
        	dom = document.createElement("INPUT");
            dom.type = "checkbox";
            dom.value = "on";
            break;
        case "rg":
            dom = createRadioGroup(data.id);
            break;
        case "ac":
        	dom = document.createElement("INPUT");
            dom.type = "text";
            arr2 = undefined;
            try {
                switch(data.autocomplete){
                    case "ciuo":
                        //alert(ciuo);
                        arr2 = ciuo.split(",");
                    break;
                    case "diseases":
                        arr2 = diseases.split(",");
                    break;
                    case "cups":
                        arr2 = cups.split(",");
                    break;
                    case "medicaments":
                        arr2 = cums.split(",");
                    break;
                    default:
                        console.log(data.autocomplete);
                    break;
                }
                $( dom ).autocomplete({
                    source: arr2,
                    position: { my: "left bottom", at: "left top", collision: "fit flip" },
                    messages: {
                        noResults: '',
                        results: ''
                    }
                });
            } catch (e){}
            break;
        case "tv":
        	dom = document.createElement("P");
            break;
        case "sp":
        	dom = document.createElement("SELECT");
            dom = createSpinnerOptions(data.id, dom);
            dom.className = "ui-selectmenu-button ui-widget ui-state-default ui-corner-all";
            break;
        default:
        	//dom = document.createElement("P");
        	dom = document.createTextNode(" El objeto "+data.objectType+" esta pendiente de desarrollar");
        	//dom.setAtr
        	break;
	}
    //if((data.objectType != "rg") && (data.objectType != "cb") && (data.objectType != "tv"))
    //    dom.className = "form-control";
    //dom.style.width = 200;
    dom.id = data.id;
    addNodeListener(dom);
	return dom;
}

function setRules(rule){
    switch (rule) {
        case "int":
            return "number";
        case "eml":
            return "email";
        case "dec":
            return "number";
        default:
            return "text";
    }
}

function createRadioGroup(id){
    var tmp = document.createElement("DIV");
    for( i in options){
        for (x in options[i].Field){
            if(options[i].Field[x] == id){
                for(b in options[i].Options){
                    if(options[i].Options[b] != "-") {
                        var rb_tmp = document.createElement("INPUT");
                        rb_tmp.type = "RADIO";
                        rb_tmp.name = id;
                        rb_tmp.value = options[i].Options[b];
                        tmp.appendChild(rb_tmp);
                        tmp.appendChild(document.createTextNode(options[i].Options[b]));
                        //tmp.appendChild(document.createTextNode(""));
                    }
                }
            }
        }
    }
    return tmp;
}

function createSpinnerOptions(id, node){
    for( i in options){
        for (x in options[i].Field){
            if(options[i].Field[x] == id){
                for(b in options[i].Options){
                    var opt = document.createElement("OPTION");
                    opt.value = opt.textContent = options[i].Options[b];
                    node.appendChild(opt);
                }
            }
        }
    }
    return node;
}

function getFormIndex(formId){
    var a;
    for ( a = forms.length - 1 ; a >= 0  ; a-- ) {
        if(forms[a].Id == formId)
            break;
    }
    if(a == -1)
        return 0;
    return a;
}

function createNextBackButton(){
    dNBButton   = document.createElement("DIV");
    nButton     = document.createElement("BUTTON");
    bButton     = document.createElement("BUTTON");

    nButton.appendChild(document.createTextNode(bt_next));
    bButton.appendChild(document.createTextNode(bt_back));

    nButton.className = "ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only";
    bButton.className = "ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only";

    //nButton.className = bButton.className = "btn btn-lg btn-success btn-block";

    dNBButton.appendChild(bButton);
    dNBButton.appendChild(nButton);
}

function addNBButtonHandler(){
    $( nButton ).click(function() {
        ss = 1;
        changeForm();
    });
    $( bButton ).click(function() {
        ss = -1;
        changeForm();
    });
}

function addNodeListener(dom){
    $( dom ).change(function() {
        getNodeHandler(dom, nodeHandlerMatch);
        getNodeHandlerJoiner(dom, nodeHandlerMatch);
    });
}

function nodeHandlerMatch(cs, match, index){
    if(index == undefined) return;
    index = index.split(",");
    if(cs == 0)
        for(n = 0; n < index.length; n++)
            ((match) ? showSubForm(index[n]) : hideSubForm(index[n]));
    else {
        match = match.split(",");
        if(index.length == match.length){
            for( m in index){
                if ((match[m] == "true")) showSubForm(index[m]);
                else hideSubForm(index[m]);
            }
        } else {
            console.log("something wrong");
        }
    }
}

function validateRequired(){
    var children = formContainer[currentForm].cluster.childElementCount;
    for (var a = 0; a < children; a++ ){
        if(formContainer[currentForm].cluster.children[a].childElementCount > 0){
            var children2 = formContainer[currentForm].cluster.children[a].childElementCount;
            for (var b = 0; b < children2; b++) {
                if((formContainer[currentForm].cluster.children[a].children[b].value != "") ||
                    (formContainer[currentForm].cluster.children[a].children[b].value != undefined)){
                    console.log(formContainer[currentForm].cluster.children[a].children[b].value+"<------value");
                    console.log("childrens = "+children2);
                }
            }
        }
    }
    return true;
}