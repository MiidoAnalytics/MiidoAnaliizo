function createInterface(data){
	for (var i = 0; i < data.length; i++) {
		var iForm = getFormIndex(data[i].form);

		var div = document.createElement("DIV");
		var div1 = document.createElement("DIV");
		var div2 = document.createElement("DIV");
		div1.appendChild(data[i].label);
		div2.appendChild(data[i].dom);
		div1.class = "span5";
		div2.class = "span5";
		div.class  = "row"
		div.appendChild(div1);
		div.appendChild(div2);

		formContainer[iForm].cluster.appendChild(div);
		putInsiders({
			oId : data[i].id,
			fId : iForm
		});
	};
}

function putInsiders(data) {
	for (var i = 0; i < formContainer.length; i++) {
		if (formContainer[i].parent == data.oId) {
			if(formContainer[i].insider == "1"){
				try {
					if(formContainer[data.fId].id == 0){
						formContainer[i].id = formContainer[i].id * -1;
					} else {
						formContainer[data.fId].cluster.appendChild(formContainer[i].cluster);
					}
				} catch (e) {
					console.log(e);
				}
			}
		}
	};
}

function prepareElements() {
	for (var i = 0; i < formContainer.length; i++) {
		if ((formContainer[i].parent != 0) ||
			(formContainer[i].insider != 0)) {
				$(formContainer[i].cluster).hide("blind");
		}
	};
}

function showSubForm(index){
	//for (a in index) {
		try {
			//console.log(index);
			$( formContainer[index].cluster ).show( "blind", {}, "medium");
		} catch (e){ console.log("Error in index "+index); }
	//}
}

function hideSubForm(index){
	$( formContainer[index].cluster ).hide( "blind", {}, "medium");
}