function getNodeHandler(dom, callback){
	var id = dom.id;
	for( b in objectContainer){
		if( objectContainer[b].id == id ){
			for( a in handler_event ) {
				if (objectContainer[b].handler == handler_event[a].Id){
					callback(0, matchHandlerRequest(handler_event[a], dom), getFormsMap(id));
				}
			}
			return 0;
		}
	}
	return 0;
}

function getNodeHandlerJoiner(dom, callback){
	var id = dom.id;
	var index = "";
	var match = "";
	//console.log(id);
	for ( g in handlerFieldJoiner ){
		for( h in handlerFieldJoiner[g].idFields){
			if (handlerFieldJoiner[g].idFields[h] == id){
				if(index.length > 0) {index += ","; match += ",";}
				//console.log(handlerFieldJoiner[g].TargetForm);
				index += getFormIndex2(handlerFieldJoiner[g].TargetForm);
				match += matchHandlerJoinerRequest(g);
			}
		}
	}
	//console.log(index);
	//console.log(match);
	if((index.length > 0) && (match.length > 0)){
		callback(1, match, index);
	}
}

function matchHandlerRequest(hCopy, dom){
	var val = dom.value;
	if(hCopy.Types.length == 0) return false;
	if(val == undefined){
		var children = dom.childElementCount;
		for( c = 0; c < children; c++){
			if(dom.children[c].checked)
				val = dom.children[c].value;
		}
	}
	//console.log(val);
	if(val != undefined) {
		var e = 0;
		for ( d in hCopy.Types ){
			switch(hCopy.Types[d]){
				case "<":
					try {
						if(parseInt(val) < parseInt(hCopy.Parameters[d]))
							e++;
					} catch (ex){ console.log(ex); }
				break;
				case ">":
					try {
						if(parseInt(val) > parseInt(hCopy.Parameters[d]))
							e++;
					} catch (ex){ console.log(ex); }
				break;
				case "!=":
					if(val != hCopy.Parameters[d])
						e++;
				break;
				case "=":
					if(val == hCopy.Parameters[d])
						e++;
				break;
			}
		}
		//console.log(e);
		return  (e == hCopy.Types.length);
	}
	return false;
}

function getFormsMap(id){
	if(id == undefined) return id;
	var index = "";
	for( f in forms) {
		if( (forms[f].Handler == 0) && (forms[f].Parent == id) ){
			if(index.length > 0) index += ",";
			index += ""+getFormIndex2(forms[f].Id);
		}
	}
	return index;
}

function getFormIndex2(id){
	if(id == undefined) return id;
	for( l in formContainer ){
		if( formContainer[l].id == id ){
			//console.log(l+"---"+id);
			return l;
		}
	}
	//console.log("returning null");
	return null;
}

function matchHandlerJoinerRequest(jhIndex){
	//var jhe = handlerFieldJoiner[jhIndex];
	var count = 0;
	for(i in handlerFieldJoiner[jhIndex].idFields) {
		for(j in objectContainer){
			if(handlerFieldJoiner[jhIndex].idFields[i] == objectContainer[j].id){
				for (k in handler_event){
					if(handler_event[k].Id == handlerFieldJoiner[jhIndex].idHandlers[i]){
						if (matchHandlerRequest(handler_event[k], objectContainer[j].dom)){
							count++;
						}
					}
				}
			}
		}
	}
	//console.log(handlerFieldJoiner[jhIndex].idFields.length+" ==? "+count);
	return (handlerFieldJoiner[jhIndex].idFields.length == count);
}